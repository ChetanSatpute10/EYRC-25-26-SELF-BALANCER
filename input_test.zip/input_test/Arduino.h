#ifndef ARDUINO_H
#define ARDUINO_H

#include <cstdint>
#include <string>
#include <cstdlib>
#include <chrono>
#include <cmath>

// Math constants
#ifndef PI
#define PI 3.14159265359
#endif

// Type definitions
typedef unsigned char byte;
typedef bool boolean;

// Serial class stub
class SerialClass {
public:
    void begin(unsigned long baud) {}
    void print(const char* str) {}
    void println(const char* str) {}
    void print(int val) {}
    void println(int val) {}
    void print(float val) {}
    void println(float val) {}
    void println() {}
};

extern SerialClass Serial;

// TwoWire class for I2C communication
class TwoWire {
public:
    TwoWire() {}
    virtual ~TwoWire() {}
    virtual void begin() {}
    virtual void begin(uint8_t address) {}
    virtual void beginTransmission(uint8_t address) {}
    virtual byte endTransmission(bool stopBit = true) { return 0; }
    virtual size_t write(byte data) { return 1; }
    virtual size_t write(const uint8_t *data, size_t quantity) { return quantity; }
    virtual int available() { return 0; }
    virtual int read() { return 0; }
    virtual int peek() { return 0; }
    virtual void flush() {}
    virtual void requestFrom(uint8_t address, size_t quantity) {}
    virtual void requestFrom(uint8_t address, size_t quantity, bool stopBit) {}
    virtual void onReceive(void (*function)(int)) {}
    virtual void onRequest(void (*function)()) {}
};

// Delay function
void delay(unsigned long ms);
unsigned long millis();

// Math functions
using std::sqrt;
using std::atan2;

#endif // ARDUINO_H
