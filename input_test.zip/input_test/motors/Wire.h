#ifndef I2C_H
#define I2C_H

#include <stdint.h>

// Initialize I2C with desired SCL frequency (e.g., 100000 for 100kHz)
void I2C_init(uint32_t scl_clock);

// Basic I2C operations
void I2C_start(void);
void I2C_stop(void);

// Send address (7-bit address shifted left + R/W bit)
void I2C_sendAddress(uint8_t address);

// Write a single byte
void I2C_write(uint8_t data);

// Read a byte with ACK (request more data)
uint8_t I2C_readACK(void);

// Read a byte with NACK (last byte)
uint8_t I2C_readNACK(void);

// TwoWire class for compatibility
typedef unsigned char byte;

class TwoWire {
public:
    TwoWire() {}
    virtual ~TwoWire() {}
    virtual void begin() {}
    virtual void begin(uint8_t address) {}
    virtual void beginTransmission(uint8_t address) {}
    virtual byte endTransmission(bool stopBit = true) { return 0; }
    virtual size_t write(byte data) { return 1; }
    virtual size_t write(const uint8_t *data, size_t quantity) { return quantity; }
    virtual int available() { return 0; }
    virtual int read() { return 0; }
    virtual int peek() { return 0; }
    virtual void flush() {}
    virtual void requestFrom(uint8_t address, size_t quantity) {}
    virtual void requestFrom(uint8_t address, size_t quantity, bool stopBit) {}
    virtual void onReceive(void (*function)(int)) {}
    virtual void onRequest(void (*function)()) {}
};

#endif
